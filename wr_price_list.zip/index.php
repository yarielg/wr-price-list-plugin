<?php 
//Silence is golden.

 ?>