<table class="table" id="products_dt">
    <thead class="table list-table">

    <tr>
       <!-- <th></th> Required for row details-->
        <th>ID</th>
        <th></th>

        <th scope="col">Title</th>
        <th scope="col">SKU</th>
        <th scope="col">Category</th>
        <th scope="col">Type</th>
        <th scope="col">Regular</th>
        <th scope="col">Sale</th>

        <th scope="col"></th>
    </tr>
    </thead>
    <tbody>
    </tbody>
</table>